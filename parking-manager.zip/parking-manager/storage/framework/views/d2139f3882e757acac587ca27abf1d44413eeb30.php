<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <header>
        <?php echo $__env->make('includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>          
    </header>
    <div class="main">
        <?php $__env->startSection('content'); ?>
        <?php echo $__env->yieldSection(); ?>
        
    </div>
    <footer>
        <?php echo $__env->make('includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </footer> 
</body>
</html><?php /**PATH /media/zubiri/DATUAK/mikel/Laravel/parking-manager/resources/views/layouts/master.blade.php ENDPATH**/ ?>