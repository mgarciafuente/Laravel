<?php $__env->startSection('title', 'Current parkings'); ?>

<?php $__env->startSection('content'); ?>
    <div class="cont2">
        <section>           
            <h2>Current parkings</h2>
            <div class="content">
                <table>
                    <?php if($parkings->isNotEmpty()): ?>
                        <tr>
                            <th>Plate</th>
                            <th>Brand</th>
                            <th>Model</th>
                            <th>User</th>
                            <th></th>
                        </tr>
                    <?php endif; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $parkings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($parking->plate); ?></td>
                            <td><?php echo e($parking->brand); ?></td>
                            <td><?php echo e($parking->model); ?></td>
                            <td>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user->id == $parking->id): ?>
                                        <?php echo e($user->name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo $__env->make('includes/delete', ['text' => 'Delete'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td class="red">No results found</td><td></td></tr>
                    <?php endif; ?>
                </table>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/zubiri/DATUAK/mikel/Laravel/parking-manager/resources/views/current.blade.php ENDPATH**/ ?>