<div class="cont">
    <p>&copy; Mikel García Fuente</p>
    <p>CFGS DAW Zubiri Manteo | DWES 2022-2023</p>
</div><?php /**PATH /media/zubiri/DATUAK/mikel/Laravel/parking-manager/resources/views/includes/footer.blade.php ENDPATH**/ ?>