<?php $__env->startSection('title', 'New user'); ?>

<?php $__env->startSection('content'); ?>
    <div class="cont2">
        <section>           
            <h2>New user</h2>
            <div class="content">
                <form action="<?php echo e(route('store-user')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php if($errors->has('name')): ?>
                        <span class="warning"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                    <input type="text" name="name" placeholder="Name" value="<?php echo e(old('name')); ?>"  <?php if($errors->has('name')): ?> class="error" <?php endif; ?>>
                    <?php if($errors->has('dni')): ?>
                        <span class="warning"><?php echo e($errors->first('dni')); ?></span>
                    <?php endif; ?>
                    <input type="text" name="dni" placeholder="DNI" value="<?php echo e(old('dni')); ?>"  <?php if($errors->has('dni')): ?> class="error" <?php endif; ?>>
                    <button class="button" type="submit" name="submit">Add</button>
                </form>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/zubiri/DATUAK/mikel/Laravel/parking-manager/resources/views/new-user.blade.php ENDPATH**/ ?>