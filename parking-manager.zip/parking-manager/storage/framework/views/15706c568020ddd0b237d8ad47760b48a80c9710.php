<?php $__env->startSection('title', 'Parking manager'); ?>

<?php $__env->startSection('content'); ?>
    <div class="cont2">
        <section>
            <ul class="content">
                <li><a class="button" href="<?php echo e(route('new')); ?>">New parking</a></li>
                <li><a class="button" href="<?php echo e(route('current')); ?>">Current parkings</a></li>
                <li><a class="button" href="<?php echo e(route('search')); ?>">Search parking</a></li>
                <li><a class="button" href="<?php echo e(route('new-user')); ?>">New user</a></li>
                <li><a class="button" href="<?php echo e(route('assign-user')); ?>">Assign user</a></li>
            </ul>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/zubiri/DATUAK/mikel/Laravel/parking-manager/resources/views/home.blade.php ENDPATH**/ ?>