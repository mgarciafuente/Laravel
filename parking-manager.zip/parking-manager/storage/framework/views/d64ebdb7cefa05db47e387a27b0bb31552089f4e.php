<?php $__env->startSection('title', 'Assign user'); ?>

<?php $__env->startSection('content'); ?>
    <div class="cont2">
        <section>           
            <h2>Assign user</h2>
            <div class="content">
                <form action="<?php echo e(route('store-assigment')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <select name="car">
                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($car->id); ?>"><?php echo e($car->plate); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <select name="user">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button class="button" type="submit" name="submit">Add</button>
                </form>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/zubiri/DATUAK/mikel/Laravel/parking-manager/resources/views/assign-user.blade.php ENDPATH**/ ?>