<?php $__env->startSection('title', 'New parking'); ?>

<?php $__env->startSection('content'); ?>
    <div class="cont2">
        <section>           
            <h2>New parking</h2>
            <div class="content">
                <form action="<?php echo e(route('store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php if($errors->any()): ?>
                        <span class="warning">
                            <?php echo e(implode('', $errors->all(':message'))); ?>

                        </span>
                    <?php endif; ?>
                    <input type="text" name="plate" placeholder="Plate" value="<?php echo e(old('plate')); ?>"  <?php if($errors->has('plate')): ?> class="error" <?php endif; ?>>
                    <input type="text" name="brand" placeholder="Brand" value="<?php echo e(old('brand')); ?>"  <?php if($errors->has('brand')): ?> class="error" <?php endif; ?>>
                    <input type="text" name="model" placeholder="Model" value="<?php echo e(old('brand')); ?>"  <?php if($errors->has('model')): ?> class="error" <?php endif; ?>>
                    <button class="button" type="submit" name="submit">Add</button>
                </form>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/zubiri/DATUAK/mikel/Laravel/parking-manager/resources/views/new.blade.php ENDPATH**/ ?>