<form action="<?php echo e(route('destroy', ['id' => $parking->id])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <button type="submit" class="delete"><?php echo e($text); ?></button>
</form><?php /**PATH /media/zubiri/DATUAK/mikel/Laravel/parking-manager/resources/views/includes/delete.blade.php ENDPATH**/ ?>