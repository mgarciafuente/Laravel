<div class="cont">
    <a href="<?php echo e(route('index')); ?>"><h1>Parking manager</h1></a>
    <?php if(!(isset($menu) && $menu == 'no')): ?> 
        <nav>
            <button class="menu">
                <span class="line1"></span>
                <span class="line2"></span>
                <span class="line3"></span>
            </button>
            <ul class="navul">
                <li><a href="<?php echo e(route('new')); ?>" <?php if($view_name == 'new'): ?> class="disabled" <?php endif; ?>>New parking</a></li>
                <li><a href="<?php echo e(route('current')); ?>"  <?php if($view_name == 'current'): ?> class="disabled" <?php endif; ?>>Current parkings</a></li>
                <li><a href="<?php echo e(route('search')); ?>"  <?php if($view_name == 'search'): ?> class="disabled" <?php endif; ?>>Search parking</a></li>
                <li><a href="<?php echo e(route('new-user')); ?>"  <?php if($view_name == 'new-user'): ?> class="disabled" <?php endif; ?>>New user</a></li>
                <li><a href="<?php echo e(route('assign-user')); ?>"  <?php if($view_name == 'assign-user'): ?> class="disabled" <?php endif; ?>>Assign user</a></li>
            </ul>
        </nav>
    <?php endif; ?>
</div> <?php /**PATH /media/zubiri/DATUAK/mikel/Laravel/parking-manager/resources/views/includes/header.blade.php ENDPATH**/ ?>