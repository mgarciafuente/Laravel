<div class="cont">
    <p>&copy; Mikel García Fuente</p>
    <p>CFGS DAW Zubiri Manteo | DWES 2022-2023</p>
</div>